import React from 'react'
import { BrowserRouter as Router, Route ,Link} from 'react-router-dom';

class Reservation extends React.Component{

    constructor(props){
        super(props)
    }
    componentDidMount(){
      fetch('/ajax/dashboard/my_reservations')
      .then(response => response.json())
      .then(data => {
        console.log(data)
        this.setState({
          page_data: data.page_data
        })
      });
    }
    render(){
        return(
            <div className="page-container-responsive space-top-4 space-4">
            <div className="row">
              <div className="col-md-3 col-sm-12 lang-chang-label">
                <ul className="sidenav-list">
                <li>
                    <Link to='/dashboard/rooms'  aria-selected={this.props.location.pathname ===  `/dashboard/rooms`} className="sidenav-item">Your Listings</Link>
                  </li>
                  <li>
                    <Link to='/dashboard/reservation'  aria-selected={this.props.location.pathname ===  `/dashboard/reservation`} className="sidenav-item">Your Reservations</Link>
                  </li>
                
                </ul>        
              </div>
              <div className="col-md-9 col-sm-12">
        <div className="your-listings-flash-container">
        </div>
        <div className="panel" id="print_area">
          <div className="panel-header">
            <div className="row row-table">
              <div className="col-md-6 col-middle mid-name-title col-sm-6">
                All Reservations
              </div>
              <div className="col-md-6 col-middle reser-cont col-sm-6">
                <a className="btn pull-right print-btn bold_non">
                  <span>Print this page
                  </span>
                  <i className="icon icon-description">
                  </i>
                </a>
              </div>
            </div>
          </div>
          <div className="table-responsive reservationsMY table_style1">
            <table style={{backgroundColor: 'white'}} className="table panel-body space-1">
              <tbody>
                <tr>
                  <th>Status
                  </th>
                  <th>Dates and Location
                  </th>
                  <th>Guest
                  </th>
                  <th>Details
                  </th>
                </tr>
                <tr data-reservation-id={10071} className="reservation">
                  <td>
                    <span className="label label-info">
                      Expired
                    </span>
                  </td>
                  <td>
                    27-06-2018 - 30-06-2018
                    <br />
                    <a locale="en"  >Ground floor – Walking distance to the lake – Newly renovated - Closest condo to the lake
                    </a>
                    <br />
                    231 Rockwood Lane
                    <br />
                    Branson,                         Missouri                         65616                        <br />
                  </td>
                  <td>
                    <div className="media va-container reserve">
                      <a className="pull-left media-photo media-round">
                        <img width={50} height={50} title="Eddie" src="https://www.vacation.rentals/images/users/10062/profile_pic_1529655118_225x225.jpg" alt="Eddie" />
                      </a>      <div className="va-top">
                        <a className="text-normal">Eddie Padin
                        </a>
                        <br />
                        <br />
                      </div>
                    </div>
                  </td>
                  <td>
                    p  667 total
                    <ul className="list-unstyled">
                      <li>
                        <a >Message History
                        </a>
                      </li>
                    </ul>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="panel-body">
            <a>View upcoming reservations
            </a>
          </div>
        </div>
      </div>
            </div>
          </div>
        )
    }
}

export default Reservation
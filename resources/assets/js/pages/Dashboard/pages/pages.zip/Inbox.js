import React from 'react'
import './inbox.css'
class Inbox extends  React.Component{
    render(){
        return(
<div className="page-container-responsive main-section">
        <div className="head-section">
          {/* <div className="headLeft-section">
            <div className="headLeft-sub">
              <input type="text" name="search" placeholder="Search..." />
              <button> <i className="fa fa-search" /> </button>
            </div>
          </div> */}
          <div className="headRight-section">
            <div className="headRight-sub">
              <h3>Lajy Ion</h3>
              <small>Lorem ipsum dolor sit amet...</small>
            </div>
          </div>
        </div>
        <div className="body-section">
          <div className="left-section mCustomScrollbar" data-mcs-theme="minimal-dark">
            <ul>
              <li>
                <div className="chatList">
                  <div className="img">
                    <i className="fa fa-circle" />
                    <img src="http://nicesnippets.com/demo/man01.png" />
                  </div>
                  <div className="desc">
                    <small className="time">05:30 am</small>
                    <h5>Luis Yankee</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <i className="fa fa-circle" />
                    <img src="http://nicesnippets.com/demo/man02.png" />
                  </div>
                  <div className="desc">
                    <small className="time">3 day</small>
                    <h5>Joi Chak</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li className="active">
                <div className="chatList">
                  <div className="img">
                    <img src="http://nicesnippets.com/demo/man03.png" />
                  </div>
                  <div className="desc">
                    <small className="time">4 day</small>
                    <h5>Lajy Ion</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <img src="http://nicesnippets.com/demo/man04.png" />
                  </div>
                  <div className="desc">
                    <small className="time">18 day</small>
                    <h5>Lod Kine</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <i className="fa fa-circle" />
                    <img src="http://nicesnippets.com/demo/man01.png" />
                  </div>
                  <div className="desc">
                    <small className="time">11:50 am</small>
                    <h5>Nik Minaj</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <img src="http://nicesnippets.com/demo/man02.png" />
                  </div>
                  <div className="desc">
                    <small className="time">20 day</small>
                    <h5>Win Sina</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <img src="http://nicesnippets.com/demo/man03.png" />
                  </div>
                  <div className="desc">
                    <small className="time">18 day</small>
                    <h5>Jack Clerk</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <img src="http://nicesnippets.com/demo/man02.png" />
                  </div>
                  <div className="desc">
                    <small className="time">20 day</small>
                    <h5>Win Sina</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
              <li>
                <div className="chatList">
                  <div className="img">
                    <img src="http://nicesnippets.com/demo/man03.png" />
                  </div>
                  <div className="desc">
                    <small className="time">18 day</small>
                    <h5>Jack Clerk</h5>
                    <small>Lorem ipsum dolor sit amet...</small>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div className="right-section">
            <div className="message mCustomScrollbar" data-mcs-theme="minimal-dark">
              <ul>
                <li className="msg-left">
                  <div className="msg-left-sub">
                    <img src="http://nicesnippets.com/demo/man03.png" />
                    <div className="msg-desc">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                    <small>05:25 am</small>
                  </div>
                </li>
                <li className="msg-right">
                  <div className="msg-left-sub">
                    <img src="http://nicesnippets.com/demo/man04.png" />
                    <div className="msg-desc">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                    <small>05:25 am</small>
                  </div>
                </li>
                <li className="msg-day"><small>Wednesday</small></li>
                <li className="msg-left">
                  <div className="msg-left-sub">
                    <img src="http://nicesnippets.com/demo/man03.png" />
                    <div className="msg-desc">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit
                    </div>
                    <small>05:25 am</small>
                  </div>
                </li>
                <li className="msg-right">
                  <div className="msg-left-sub">
                    <img src="http://nicesnippets.com/demo/man04.png" />
                    <div className="msg-desc">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                    <small>05:25 am</small>
                  </div>
                </li>
                <li className="msg-left">
                  <div className="msg-left-sub">
                    <img src="http://nicesnippets.com/demo/man03.png" />
                    <div className="msg-desc">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit
                    </div>
                    <small>05:25 am</small>
                  </div>
                </li>
                <li className="msg-right">
                  <div className="msg-left-sub">
                    <img src="http://nicesnippets.com/demo/man04.png" />
                    <div className="msg-desc">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua.
                    </div>
                    <small>05:25 am</small>
                  </div>
                </li>
              </ul>
            </div>
            <div className="right-section-bottom">
              <form>
                <div className="upload-btn">
                  <button className="btn"><i className="fa fa-photo" /></button>
                  <input type="file" name="myfile" />
                </div>
                <input type="text"  placeholder="type here..." />
                <button className="btn-send"><i className="fa fa-send" /></button>
              </form>
            </div>
          </div>
        </div>
      </div>
        )
    }
}

export default Inbox
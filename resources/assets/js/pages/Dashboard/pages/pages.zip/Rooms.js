import React from 'react'
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

import './room.css'
import Axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class Rooms extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      page_data: []
    }
    this.handleChangeStatus = this.handleChangeStatus.bind(this)
    this.handlePublish = this.handlePublish.bind(this)
  }
  componentDidMount() {
    fetch('/ajax/dashboard/getlistings')
      .then(response => response.json())
      .then(data => {
        console.log(data)
        this.setState({
          page_data: data.page_data
        })
      });
  }
  handleChangeStatus(list_id, event) {
    event.preventDefault();
    console.log(list_id, event)
    let value = event.target.value
    let list_index = this.state.page_data.rooms_list.filter((list) => list.id === list_id)
    list_index = this.state.page_data.rooms_list.indexOf(list_index[0])
    let {page_data} = this.state;
    console.log(list_index)
    page_data.rooms_list[list_index].status = value
    page_data.rooms_list[list_index].published = 'unpublished'
    this.setState({
      page_data : page_data
    })

  }
  handlePublish(list_id, event){
    event.preventDefault();
    console.log(list_id, event)
    let value = event.target.value
    let list_index = this.state.page_data.rooms_list.filter((list) => list.id === list_id)
    let temp_room = list_index[0]
    list_index = this.state.page_data.rooms_list.indexOf(list_index[0])
    let {page_data} = this.state;
    console.log(list_index)
    // page_data.rooms_list[list_index].status = value
    Axios.post('/ajax/change_status_of_room',{room_id : list_id, status : temp_room.status} )
    .then(response => {
      console.log(response)
      if(response.data.status == 'success'){
        toast.success(response.data.message,{
          position: toast.POSITION.TOP_CENTER
        } )
        page_data.rooms_list[list_index].published = 'published'
        this.setState({
          page_data : page_data
        })
      }
      
    })
    .catch(err => {
      toast.error('Error!!!',{
        position: toast.POSITION.TOP_CENTER
      } )
    })
    
      
  }
  render() {
    let { page_data } = this.state;
    let listed_result_section = []
    let unlisted_result_section = []
    if(page_data.rooms_list && page_data.rooms_list.length){
      page_data.rooms_list.map((list) => {
        const room_list = <li className="listing panel-body" key={list.id}>
        <div className="row row-table" key={list.id}>
          <div className="col-lg-2 col-md-2 list_reserve_img col-middle">
            <a >
              <div className="media-photo media-photo-block">
                <div className="media-cover text-center">
                  <img src={list.featured_image} className="img-responsive-height" />
                </div>
              </div>
            </a>
          </div>
          <div className="col-lg-7 col-md-6 list_reserve col-middle">
            <span className="h4">
              <a className="text-normal">{list.name}</a>
            </span>
            <div className="actions row-space-top-1">
              <a className="listing-link-space" >Manage Listing and Calendar</a>
            </div>
            <div className="listing-criteria-header activation-notification hide-md show-sm space-top-2">
              <div className="listing-criteria-header-message">
                <div id="availability-dropdown" className="show-sm hide-md" data-room-id="div_10001">
                  <i className="dot row-space-top-2 col-top dot-success" />&nbsp;
        <div className="select">
                    <select className="room_status_dropdown" data-room-id={list.id} value={list.status} onChange={(event) => this.handleChangeStatus(list.id, event)}>
                      <option value="Listed" >Listed</option>
                      <option value="Unlisted">Unlisted</option>
                      <option value="Draft">Draft</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 list_reserve col-middle text-right">
            <div className="listing-criteria-header activation-notification">
              <div className="listing-criteria-header-message">
                <div id="availability-dropdown" className="hide-sm show-md show-lg" data-room-id="div_10001">
                  <i className="dot row-space-top-2 col-top dot-success" />&nbsp;
        <div className="select">
                    <select className="room_status_dropdown"  data-room-id={list.id} value={list.status} onChange={(event) => this.handleChangeStatus(list.id, event)}>
                      <option value="Listed" >Listed</option>
                      <option value="Unlisted">Unlisted</option>
                      <option value="Draft">Draft</option>
                    </select>
                  </div>
                </div>
                <br />
                { list.published != 'unpublished' ? <span>Published</span> : <a href="javascript:void(0)" data-id={list.id} className="btn btn-host btn-primary subscribe-property-btn" onClick={(event)=>this.handlePublish(list.id, event)}>Publish</a>}
              </div>
            </div>
          </div>
        </div>
        <div className="loading global-ajax-form-loader d-none" />
                      </li>
        if(list.status == 'Listed'){
            listed_result_section.push(room_list)
        }
        else{
            unlisted_result_section.push(room_list)
        }
      })
    }
     
    return (
      <div className="page-container-responsive space-top-4 space-4">
      <ToastContainer/>
        <div className="row">
          <div className="col-md-3 col-sm-12 lang-chang-label">
            <ul className="sidenav-list">
              <li>
                <Link to='/dashboard/rooms' aria-selected={this.props.location.pathname === `/dashboard/rooms`} className="sidenav-item">Your Listings</Link>
              </li>
              <li>
                <Link to='/dashboard/reservation' aria-selected={this.props.location.pathname === `/dashboard/reservation`} className="sidenav-item">Your Reservations</Link>
              </li>

            </ul>
          </div>
          <div className="col-md-9 col-sm-12">
            <div className="your-listings-flash-container" />
            <div id="listings-container">
              <div>
                <div className="suspension-container">
                  <div className="suspension-overlay hide" />
                  <div className="panel row-space-4">
                    <div className="panel-header active-panel-header">
                      <div className="row">
                        <div className="col-md-12 active-panel-padding lang-chang-label">Listed</div>
                        <div id="ib-master-switch-container" className="col-6" />
                      </div>
                    </div>
                    <ul className="list-unstyled list-layout">
                      
                        {listed_result_section}
                       </ul>
                  </div>
                  <div className="panel row-space-4">
                    <div className="panel-header active-panel-header">
                      <div className="row">
                        <div className="col-md-12 active-panel-padding">Unlisted</div>
                        <div id="ib-master-switch-container" className="col-6" />
                      </div>
                    </div>
                    <ul className="list-unstyled list-layout">
                    {unlisted_result_section}
                      </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Rooms
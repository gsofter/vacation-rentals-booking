import React from 'react'

class CurrentTrips extends React.Component{
    render(){
        return(<div className="panel row-space-4">
        <div className="panel-header">
          Current Trips
        </div>
        <div className="table-responsive">
          <table className="table panel-body panel-light">
          <tbody>
              <tr>
                <th>Status
                </th>
                <th>Location
                </th>
                <th>Host
                </th>
                <th>Dates
                </th>
                <th>Options
                </th>
              </tr>
              <tr>
                <td className="status">
                  <span className="label label-orange label-info">
                    <span className="label label-info">
                      Declined
                    </span>
                  </span>
                  <br />
                </td>
                <td className="location">
                  <a   >
                  </a>
                  <br />      
                  Bradenton Beach
                </td>
                <td className="host">
                  <a >Irene Proudlove
                  </a>
                </td>
                <td className="dates">16-11-2018 - 23-11-2018
                </td>
                <td>
                  <ul className="unstyled button-list list-unstyled">
                    <li className="row-space-1">
                      <a className="button-steel"  >Message History
                      </a>
                    </li>
                  </ul>
                </td>
              </tr>   
              </tbody>                      
          </table>
        </div>
      </div>)
    }
}

export default CurrentTrips
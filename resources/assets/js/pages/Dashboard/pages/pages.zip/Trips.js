import React from 'react'
import { BrowserRouter as Router, Route ,Link} from 'react-router-dom';
import CurrentTrips from './trips/CurrentTrips'
import OldTrips from './trips/OldTrips'
class Trips extends React.Component{
    render(){
        return(
            <div className="page-container-responsive space-top-4 space-4">
        <div className="row">
          <div className="col-md-3 trip-left-sec">
            <ul className="sidenav-list">
              <li>
              <Link to='/dashboard/mytrips'  aria-selected={this.props.location.pathname ===  `/dashboard/mytrips`} className="sidenav-item">Your Trips</Link>

                
              </li>
              <li>
              <Link to='/dashboard/oldtrips'  aria-selected={this.props.location.pathname ===  `/dashboard/oldtrips`} className="sidenav-item">Your Previous Trips</Link>
                
              </li>
            </ul>    </div>
          <div className="col-md-9 trip-right-sec">
                <Route exact path='/dashboard/mytrips' component={CurrentTrips}/>
                <Route  path='/dashboard/oldtrips' component={OldTrips}/>
          </div>
        </div>
      </div>
        )
    }
}

export default Trips
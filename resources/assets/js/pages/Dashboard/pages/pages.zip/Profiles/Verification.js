import React from 'react'

class Verification extends React.Component{
    render(){
        return(
            <div className="col-md-9">
        <div id="dashboard-content">
          <div className="panel verified-container">
            <div className="panel-header">
              Your Current Verifications
            </div>
            <div className="panel-body">
              <ul className="list-layout edit-verifications-list">
                <li className="edit-verifications-list-item clearfix email verified">
                  <h4>Email Address</h4>
                  <p className="description">You have confirmed your email: <b>sales@vacarent.com</b>.  A confirmed email is important to allow us to securely communicate with you.
                  </p></li>
                <li className="edit-verifications-list-item clearfix email verified">
                  <h4>Phone Number</h4>
                  <p className="description">You have confirmed your phone number: <b>* * * * * * * * * 717</b>.
                  </p></li>
              </ul>
            </div>
          </div>
          <div className="panel row-space-top-4 unverified-container">
            <div className="panel-header">
              Add More Verifications
            </div>
            <div className="panel-body">
              <ul className="list-layout edit-verifications-list">
                <li className="facebook unverified row-space-4 clearfix">
                  <h4>
                    Facebook
                  </h4>
                  <div className="row">
                    <div className="col-7 lang-chang-label">
                      <p className="description verification-text-description">
                        Sign in with Facebook and discover your trusted connections to hosts and guests all over the world.
                      </p>
                    </div>
                    <div className="col-5">
                      <div className="connect-button">
                        <a  className="btn btn-block large facebook-button">Connect</a>
                      </div>
                    </div>
                  </div>
                </li>
                <li className="google unverified row-space-4 clearfix">
                  <h4>
                    Google
                  </h4>
                  <div className="row">
                    <div className="col-7 lang-chang-label">
                      <p className="description verification-text-description">
                        Connect your Vacation.Rentals----- account to your Google account for simplicity and ease.
                      </p>
                    </div>
                    <div className="col-5">
                      <div className="connect-button">
                        <a className="btn btn-block large" >
                          Connect
                        </a>
                      </div>
                    </div>
                  </div>
                </li>
                <li className="linkedin unverified row-space-4 clearfix">
                  <h4>
                    LinkedIn
                  </h4>
                  <div className="row">
                    <div className="col-7 lang-chang-label">
                      <p className="description verification-text-description">
                        Create a link to your professional life by connecting your Vacation.Rentals----- and LinkedIn accounts.
                      </p>
                    </div>
                    <div className="col-5">
                      <div className="connect-button">
                        <a className="btn btn-block" >Connect</a>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
        )
    }
}

export default Verification
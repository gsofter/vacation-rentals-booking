import React from "react";
import ReactDOM from "react-dom";
import { compose, withProps, withHandlers } from "recompose";

import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker
} from "react-google-maps";
import { MarkerClusterer }  from "react-google-maps/lib/components/addons/MarkerClusterer"



 
const MapContanier = compose(
  withProps({
    googleMapURL:
      "https://maps.googleapis.com/maps/api/js?key=AIzaSyA34nBk3rPJKXaNQaSX4YiLFoabX3DhkXs&v=3.exp&libraries=geometry,drawing,places",
    loadingElement: <div style={{ height: `100%` }} />,
    containerElement: <div style={{ height: `400px` }} />,
    mapElement: <div style={{ height: `100%` }} />
  }),
  withScriptjs,
  withGoogleMap,
)(props => {
    return (<CustomMap mapdata={props}/>)
}
  
);

export default MapContanier


class CustomMap  extends React.PureComponent{
  constructor(props){
    super(props)
    this.state = {
      mapdata :this.props.mapdata
    }
  }
  componentWillReceiveProps(nextProps){
    this.setState({
      mapdata : nextProps.mapdata
    })
  }
  render(){
    console.log('updating...', this.state)
      return <GoogleMap defaultZoom={8} defaultCenter={{ lat: this.state.mapdata.lat, lng: this.state.mapdata.lng }} onDragEnd={this.state.mapdata.onDragEnd}  onZoomChanged={this.state.mapdata.onZoomChanged} onCenterChanged={this.state.mapdata.onCenterChanged}  ref={this.state.mapdata.onMapMounted} onBoundsChanged={this.state.mapdata.onBoundsChanged}>
      { 
       this.state.mapdata.listings.map((listing) =>{
          <Marker position={{ lat: listing.latitude, lng: listing.longitude }} />
       })
     }
     
   </GoogleMap>
   
    
  }

}